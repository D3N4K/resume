﻿using ISvuz.Windows;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ISvuz.Classes
{
    internal class Autorization
    {
        public int CheckAutorize(string login, string password)
        {
            try
            {
                using (SqlConnection connect = new SqlConnection(Connection.connString))
                {
                    connect.Open();
                    if (!(login != "" && password != ""))
                    {
                        MessageBox.Show("Введите данные"); return 0;
                    }
                    string sqlExp = "select [id_user],[FirstName],[LastName],[Patronymic],[Email],[Passwordik],[id_role] from [dbo].[Users] where [Login] = @login";
                    SqlCommand cmd = new SqlCommand(sqlExp, connect);
                    cmd.Parameters.AddWithValue("@login", login);
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        AutorizationWindow.Fio = reader["FirstName"].ToString() + " " + reader["LastName"].ToString() + " " + reader["Patronymic"].ToString();
                        AutorizationWindow.UserId = int.Parse(reader["id_user"].ToString());
                        if (Verification.VerifySHA512Hash(password, reader["Passwordik"].ToString()))
                        {
                            return int.Parse(reader["id_role"].ToString());
                        }
                        else
                        {
                            MessageBox.Show("Неверный пароль");
                            password = "";
                            return -1;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Нет такого пользователя");
                        login = "";
                        password = "";
                        return 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return 0;
            }
        }
    }
}
