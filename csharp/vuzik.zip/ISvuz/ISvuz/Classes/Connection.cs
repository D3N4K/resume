﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISvuz.Classes
{
    internal class Connection
    {
        //internal static string connString = @"Data Source=172.20.105.2;User ID=9po11-20-28;Password=kiejuCha;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;Initial Catalog=Teatre";
        internal static string connString = @"Data Source=LAPTOP-U4M3FUAO\MSSQLSERVER1;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;Initial Catalog=VUZ";
    }
}
