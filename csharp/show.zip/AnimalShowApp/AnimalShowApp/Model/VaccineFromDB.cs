﻿using AnimalShowApp.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AnimalShowApp.Model
{
    internal class VaccineFromDB
    {
        public List<Vaccine> LoadVaccine(int idAnimal)
        {
            List<Vaccine> vaccines = new List<Vaccine>();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectVaccine";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idAnimal", idAnimal);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        vaccines.Add(new Vaccine(Convert.ToInt32(reader[0]), reader[1].ToString(), reader[2].ToString()));
                    }
                }
                reader.Close();
                return vaccines;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return vaccines;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
