﻿using AnimalShowApp.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AnimalShowApp.Model
{
    internal class OwnerFromDB
    {
        public Owner LoadOwner(int idAnimal)
        {
            Owner owner = new Owner();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectOwner";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idAnimal", idAnimal);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    owner.Id = Convert.ToInt32(reader[0]);
                    owner.FirstName = reader[1].ToString();
                    owner.LastName = reader[2].ToString();
                    owner.Patronymic = reader[3].ToString();
                    owner.SeriaPassport = reader[4].ToString();
                    owner.NumberPassport = reader[5].ToString();
                    owner.Issued = reader[6].ToString();
                    owner.DateOfBirthday = reader[7].ToString();
                }
                reader.Close();
                return owner;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return owner;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
