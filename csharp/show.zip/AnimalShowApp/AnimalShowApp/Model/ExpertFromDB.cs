﻿using AnimalShowApp.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AnimalShowApp.Model
{
    internal class ExpertFromDB
    {
        public List<Expert> LoadExpert(int idShow)
        {
            List<Expert> experts = new List<Expert>();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectExpert";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idShow", idShow);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        experts.Add(new Expert(Convert.ToInt32(reader[0]), reader[1].ToString(), reader[2].ToString(), reader[3].ToString()));
                    }
                }
                reader.Close();
                return experts;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return experts;
            }
            finally
            {
                connection.Close();
            }
        }
        public void DeleteExpert(int idShow, int idExpert)
        {
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "DeleteExpert";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idShow", idShow);
                command.Parameters.AddWithValue("@idExpert", idExpert);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        public List<ExpertFull> LoadAllExpert()
        {
            List<ExpertFull> experts = new List<ExpertFull>();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectAllExpert";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        experts.Add(new ExpertFull(Convert.ToInt32(reader[0]), reader[1].ToString()));
                    }
                }
                reader.Close();
                return experts;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return experts;
            }
            finally
            {
                connection.Close();
            }
        }
        public void AddExpert(int ring, int expert, int show)
        {
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "AddExpert";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ring", ring);
                command.Parameters.AddWithValue("@expert", expert);
                command.Parameters.AddWithValue("@show", show);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        public List<Expert> LoadExpertBycLub(int idShow, int idClub)
        {
            List<Expert> experts = new List<Expert>();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectExpertByClub";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idShow", idShow);
                command.Parameters.AddWithValue("@idClub", idClub);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        experts.Add(new Expert(Convert.ToInt32(reader[0]), reader[1].ToString(), reader[2].ToString(), reader[3].ToString()));
                    }
                }
                reader.Close();
                return experts;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return experts;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
