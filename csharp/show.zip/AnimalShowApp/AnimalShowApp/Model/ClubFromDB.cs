﻿using AnimalShowApp.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AnimalShowApp.Model
{
    internal class ClubFromDB
    { 
        public List<Club> LoadClub()
        {
            List<Club> clubs = new List<Club>();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectClub";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        clubs.Add(new Club(Convert.ToInt32(reader[0]), reader[1].ToString()));
                    }
                }
                reader.Close();
                return clubs;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return clubs;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
