﻿using AnimalShowApp.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AnimalShowApp.Model
{
    internal class ShowFromDB
    {
        public List<Show> LoadShow()
        {
            List<Show> shows = new List<Show>();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectShow";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader reader = command.ExecuteReader();
                if(reader.HasRows)
                {
                    while(reader.Read())
                    {
                        shows.Add(new Show(Convert.ToInt32(reader[0]), reader[1].ToString(), reader[2].ToString(), reader[3].ToString()));
                    }
                }
                reader.Close();
                return shows;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                return shows;
            }
            finally
            {
                connection.Close();
            }
        }
        public void DeleteShow(int idShow)
        {
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "DeleteShow";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idShow", idShow);
                command.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        public void AddShow(string name, DateTime date, string time)
        {
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "AddShow";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@name", name);
                command.Parameters.AddWithValue("@date", date);
                command.Parameters.AddWithValue("@time", time);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        public Show LoadShowById(int idShow)
        {
            Show show = new Show();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectShowById";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idShow", idShow);
                SqlDataReader reader = command.ExecuteReader();
                if(reader.HasRows)
                {
                    while(reader.Read())
                    {
                        show.Id = Convert.ToInt32(reader[0]);
                        show.NameShow = reader[1].ToString();
                        show.DateShow = reader[2].ToString();
                        show.TimeShow = reader[3].ToString();
                    }
                }
                reader.Close();
                return show;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return show;
            }
            finally
            {
                connection.Close();
            }
        }
        public void UpdateShow(int idShow, string name, DateTime date, string time)
        {
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "UpdateShow";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idShow", idShow);
                command.Parameters.AddWithValue("@name", name);
                command.Parameters.AddWithValue("@date", date);
                command.Parameters.AddWithValue("@time", time);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        public List<Show> LoadShowByDate(string date)
        {
            List<Show> shows = new List<Show>();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectShowByDate";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@date", date);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        shows.Add(new Show(Convert.ToInt32(reader[0]), reader[1].ToString(), reader[2].ToString(), reader[3].ToString()));
                    }
                }
                reader.Close();
                return shows;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return shows;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
