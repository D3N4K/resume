﻿using AnimalShowApp.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AnimalShowApp.Model
{
    internal class AnimalFromDB
    {
        public List<Animal> LoadAnimal(int idShow)
        {
            List<Animal> animals = new List<Animal>();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectAnimal";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idShow", idShow);
                SqlDataReader reader = command.ExecuteReader();
                if(reader.HasRows)
                {
                    while(reader.Read())
                    {
                        animals.Add(new Animal(Convert.ToInt32(reader[0]), Convert.ToInt32(reader[1]), reader[2].ToString(), reader[3].ToString(), Convert.ToInt32(reader[4]), reader[5].ToString(), reader[6].ToString(), reader[7].ToString(), reader[8].ToString(), Convert.ToInt32(reader[9])));
                    }
                }
                reader.Close();
                return animals;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return animals;
            }
            finally
            {
                connection.Close();
            }
        }
        public void DeleteAnimal(int idShow, int idAnimal)
        {
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "DeleteAnimal";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idShow", idShow);
                command.Parameters.AddWithValue("@idAnimal", idAnimal);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        public List<AnimalById> LoadAnimalByOwner(int idAnimal)
        {
            List<AnimalById> animals = new List<AnimalById>();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectAnimalByOwner";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idAnimal", idAnimal);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        animals.Add(new AnimalById(Convert.ToInt32(reader[0]), reader[1].ToString(), reader[2].ToString(), reader[3].ToString(), reader[4].ToString(), reader[5].ToString()));
                    }
                }
                reader.Close();
                return animals;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return animals;
            }
            finally
            {
                connection.Close();
            }
        }
        public AnimalById LoadAnimalById(int idAnimal)
        {
            AnimalById animal = new AnimalById();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectAnimalById";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idAnimal", idAnimal);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    animal.Id = Convert.ToInt32(reader[0]);
                    animal.Name = reader[1].ToString();
                    animal.Age = reader[2].ToString();
                    animal.NameClub = reader[3].ToString();
                    animal.Type = reader[4].ToString();
                    animal.Breed = reader[5].ToString();
                }
                reader.Close();
                return animal;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return animal;
            }
            finally
            {
                connection.Close();
            }
        }
        public void SetResult(int idAnimal, int idShow, int place)
        {
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SetResult";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idAnimal", idAnimal);
                command.Parameters.AddWithValue("@idShow", idShow);
                command.Parameters.AddWithValue("@place", place);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
