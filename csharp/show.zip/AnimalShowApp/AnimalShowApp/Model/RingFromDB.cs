﻿using AnimalShowApp.Classes;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AnimalShowApp.Model
{
    internal class RingFromDB
    {
        public List<Ring> LoadRing()
        {
            List<Ring> rings = new List<Ring>();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectRing";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        rings.Add(new Ring(Convert.ToInt32(reader[0]), reader[1].ToString()));
                    }
                }
                reader.Close();
                return rings;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return rings;
            }
            finally
            { 
                connection.Close(); 
            }
        }
        public List<RingHasExpert> LoadRingHasExpert(int idShow)
        {
            List<RingHasExpert> ringHasExperts = new List<RingHasExpert>();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                connection.Open();
                string query = "SelectRingHasExpert";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@idShow", idShow);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        ringHasExperts.Add(new RingHasExpert(reader[0].ToString(), reader[1].ToString(), reader[2].ToString(), reader[3].ToString()));
                    }
                }
                reader.Close();
                return ringHasExperts;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return ringHasExperts;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
