﻿using AnimalShowApp.Classes;
using AnimalShowApp.Model;
using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AnimalShowApp.Windows
{
    /// <summary>
    /// Логика взаимодействия для AnimalWindow.xaml
    /// </summary>
    public partial class AnimalWindow : Window
    {
        List<Animal> animals = new List<Animal>();
        AnimalFromDB animalFromDB = new AnimalFromDB();
        Show show = new Show();
        ShowFromDB showFromDB = new ShowFromDB();
        List<RingHasExpert> ringHasExperts = new List<RingHasExpert>();
        RingFromDB ringFromDB = new RingFromDB();
        PdfGenerator pdfGenerator = new PdfGenerator();
        int idShow = 0;
        int selectedRow = 0;
        public AnimalWindow(int idShow)
        {
            InitializeComponent();
            this.idShow = idShow;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dgAnimal.Columns[1].Visibility = Visibility.Collapsed;
            ViewAnimal();
            btnSaveResult.Visibility = Visibility.Collapsed;
            btnSaveResultAnimal.Visibility = Visibility.Collapsed;
            tbName.Visibility = Visibility.Collapsed;
            tbResult.Visibility = Visibility.Collapsed;
        }
        void ViewAnimal()
        {
            animals = animalFromDB.LoadAnimal(idShow);
            dgAnimal.DataContext = animals;
            dgAnimal.SetBinding(DataGrid.ItemsSourceProperty, new Binding() { Path = new PropertyPath(".") });
        }

        private void miDeleteAnimal_Click(object sender, RoutedEventArgs e)
        {
            if (selectedRow == 0)
            {
                MessageBox.Show("Вы не выбрали участника!");
            }
            else
            {
                if (MessageBox.Show($"Вы уверены что хотите удалить '{animals[selectedRow].Name}'?", "Предупреждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    animalFromDB.DeleteAnimal(idShow, animals[selectedRow].Id);
                    ViewAnimal();
                }
            }
        }

        private void dgAnimal_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            selectedRow = dgAnimal.SelectedIndex;
            tbName.Text = animals[selectedRow].Name;
            tbResult.Text = animals[selectedRow].Place.ToString();
        }

        private void miShowOwner_Click(object sender, RoutedEventArgs e)
        {
            if (selectedRow == 0)
            {
                MessageBox.Show("Вы не выбрали участника!");
            }
            else
            {
                OwnerWindow ownerWindow = new OwnerWindow(animals[selectedRow].Id);
                ownerWindow.Show();
            }
        }

        private void miShowVaccine_Click(object sender, RoutedEventArgs e)
        {
            if (selectedRow == 0)
            {
                MessageBox.Show("Вы не выбрали участника!");
            }
            else
            {
                VaccineWindow vaccineWindow = new VaccineWindow(animals[selectedRow].Id);
                vaccineWindow.Show();
            }
        }

        private void miSetResult_Click(object sender, RoutedEventArgs e)
        {
            btnSaveResult.Visibility = Visibility.Visible;
            btnSaveResultAnimal.Visibility = Visibility.Visible;
            tbName.Visibility = Visibility.Visible;
            tbResult.Visibility = Visibility.Visible;
        }

        private void btnSaveResult_Click(object sender, RoutedEventArgs e)
        {
            btnSaveResult.Visibility = Visibility.Collapsed;
            btnSaveResultAnimal.Visibility = Visibility.Collapsed;
            tbName.Visibility = Visibility.Collapsed;
            tbResult.Visibility = Visibility.Collapsed;
            ViewAnimal();
        }

        private void btnSaveReport_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.ShowDialog();
            Directory.CreateDirectory(saveFileDialog.FileName);
            show = showFromDB.LoadShowById(idShow);
            ringHasExperts = ringFromDB.LoadRingHasExpert(idShow);
            string reportPath = saveFileDialog.FileName + "/" + show.NameShow + ".pdf";
            pdfGenerator.GenerateReport(reportPath, show.NameShow, ringHasExperts, animals);
            for(int i = 0; i < animals.Count; i++)
            {
                if(1 <= animals[i].Place && animals[i].Place <= 3)
                {
                    string certificatePath = saveFileDialog.FileName + "/" + animals[i].Name + ".pdf";
                    pdfGenerator.GenerateCertificate(certificatePath, show.NameShow, animals[i]);
                }
            }
        }

        private void btnSaveResultAnimal_Click(object sender, RoutedEventArgs e)
        {
            animalFromDB.SetResult(animals[selectedRow].Id,idShow,Convert.ToInt32(tbResult.Text));
        }
    }
}
