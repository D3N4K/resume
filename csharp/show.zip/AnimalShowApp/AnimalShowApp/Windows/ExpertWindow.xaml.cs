﻿using AnimalShowApp.Classes;
using AnimalShowApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Collections.Specialized.BitVector32;

namespace AnimalShowApp.Windows
{
    /// <summary>
    /// Логика взаимодействия для ExpertWindow.xaml
    /// </summary>
    public partial class ExpertWindow : Window
    {
        List<Expert> experts = new List<Expert>();
        ExpertFromDB expertFromDB = new ExpertFromDB();
        List<Club> clubs = new List<Club>();
        ClubFromDB clubFromDB = new ClubFromDB();
        int idShow = 0;
        int selectedRow = 0;
        public ExpertWindow(int idShow)
        {
            InitializeComponent();
            this.idShow = idShow;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dgExpert.Columns[0].Visibility = Visibility.Collapsed;
            ViewExpert();
            LoadClub();
        }
        void ViewExpert()
        {
            experts = expertFromDB.LoadExpert(idShow);
            dgExpert.DataContext = experts;
            dgExpert.SetBinding(DataGrid.ItemsSourceProperty, new Binding() { Path = new PropertyPath(".") });
        }
        void LoadClub()
        {
            clubs = clubFromDB.LoadClub();
            cbClub.Items.Insert(0, "Выбрать");
            for(int i = 0; i < clubs.Count; i++)
            {
                cbClub.Items.Insert(clubs[i].Id, clubs[i].Name);
            }
            cbClub.SelectedIndex = 0;
        }
        private void miDeleteExpert_Click(object sender, RoutedEventArgs e)
        {
            if (selectedRow == 0)
            {
                MessageBox.Show("Вы не выбрали выставку!");
            }
            else
            {
                if (MessageBox.Show($"Вы уверены что хотите удалить '{experts[selectedRow].LastName + experts[selectedRow].FirstName}'?", "Предупреждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    expertFromDB.DeleteExpert(idShow, experts[selectedRow].Id);
                    ViewExpert();
                }
            }
        }

        private void dgExpert_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            selectedRow = dgExpert.SelectedIndex;
        }

        private void miAddExpert_Click(object sender, RoutedEventArgs e)
        {
            EditExpertWindow editExpertWindow = new EditExpertWindow(idShow);
            this.Hide();
            if (editExpertWindow.ShowDialog() == true)
            {
                ViewExpert();
                this.Show();
            }
        }

        private void tbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            dgExpert.DataContext = Search(tbSearch.Text);
        }
        List<Expert> Search(string text)
        {
            List<Expert> result = new List<Expert>();
            for (int i = 0; i < experts.Count(); i++)
            {
                if (experts[i].FirstName.ToLower().Contains(text.ToLower()) || experts[i].LastName.ToLower().Contains(text.ToLower()))
                {
                    result.Add(experts[i]);
                }
            }
            return result;
        }
        void FilterByClub(int idClub)
        {
            experts = expertFromDB.LoadExpertBycLub(idShow, idClub);
            dgExpert.DataContext = experts;
        }

        private void cbClub_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(cbClub.SelectedIndex == 0)
            {
                ViewExpert();
            }
            else
            {
                FilterByClub(cbClub.SelectedIndex);
            }
            Search(tbSearch.Text);
        }
    }
}
