﻿using AnimalShowApp.Classes;
using AnimalShowApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Collections.Specialized.BitVector32;

namespace AnimalShowApp.Windows
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Show> shows = new List<Show>();
        ShowFromDB showFromDB = new ShowFromDB();
        int selectedRow = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dgShow.Columns[0].Visibility = Visibility.Collapsed;
            ViewShow();
        }
        void ViewShow()
        {
            shows = showFromDB.LoadShow();
            dgShow.DataContext = shows;
            dgShow.SetBinding(DataGrid.ItemsSourceProperty, new Binding() { Path = new PropertyPath(".") });
        }

        private void dgShow_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            selectedRow = dgShow.SelectedIndex;
        }

        private void miSelectExpert_Click(object sender, RoutedEventArgs e)
        {
            if (selectedRow == 0)
            {
                MessageBox.Show("Вы не выбрали выставку!");
            }
            else
            {
                ExpertWindow expertWindow = new ExpertWindow(shows[selectedRow].Id);
                this.Hide();
                if (expertWindow.ShowDialog() == true)
                {
                    this.Show();
                }
            }
        }

        private void miSelectAnimal_Click(object sender, RoutedEventArgs e)
        {
            if (selectedRow == 0)
            {
                MessageBox.Show("Вы не выбрали выставку!");
            }
            else
            {
                AnimalWindow animalWindow = new AnimalWindow(shows[selectedRow].Id);
                this.Hide();
                if (animalWindow.ShowDialog() == true)
                {
                    this.Show();
                }
            } 
        }

        private void miExit_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            this.Close();
        }

        private void miDeleteShow_Click(object sender, RoutedEventArgs e)
        {
            if(selectedRow == 0)
            {
                MessageBox.Show("Вы не выбрали выставку!");
            }
            else
            {
                if (MessageBox.Show($"Вы уверены что хотите удалить '{shows[selectedRow].NameShow}'?", "Предупреждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    showFromDB.DeleteShow(shows[selectedRow].Id);
                    ViewShow();
                }
            }
        }

        private void miAddShow_Click(object sender, RoutedEventArgs e)
        {
            OpenEditWindow(0);
        }

        private void miAlterShow_Click(object sender, RoutedEventArgs e)
        {
            OpenEditWindow(1);
        }
        void OpenEditWindow(int action)
        {
            EditShowWindow editShowWindow = new EditShowWindow(action, shows[selectedRow].Id);
            this.Hide();
            if(editShowWindow.ShowDialog() == true)
            {
                this.Show();
                ViewShow();
            }
        }
        List<Show> Search(string text)
        {
            List<Show> result = new List<Show>();
            for(int i = 0; i < shows.Count(); i++)
            {
                if (shows[i].NameShow.ToLower().Contains(text.ToLower()))
                {
                    result.Add(shows[i]);
                }
            }
            return result;
        }

        private void tbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            dgShow.DataContext = Search(tbSearch.Text);
        }
        void FilterByDate(string date)
        {
            shows = showFromDB.LoadShowByDate(dpFilter.Text);
            dgShow.DataContext = shows;
        }

        private void dpFilter_CalendarClosed(object sender, RoutedEventArgs e)
        {
            if (dpFilter.Text == "" || dpFilter.Text == "Выбор даты")
            {
                ViewShow();
            }
            else
            {
                FilterByDate(dpFilter.Text);
            }
            Search(tbSearch.Text);
        }

    }
}
