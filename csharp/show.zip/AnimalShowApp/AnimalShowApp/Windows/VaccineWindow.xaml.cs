﻿using AnimalShowApp.Classes;
using AnimalShowApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AnimalShowApp.Windows
{
    /// <summary>
    /// Логика взаимодействия для VaccineWindow.xaml
    /// </summary>
    public partial class VaccineWindow : Window
    {
        int idAnimal;
        AnimalById animal = new AnimalById();
        AnimalFromDB animalFromDB = new AnimalFromDB();
        List<Vaccine> vaccines = new List<Vaccine>();
        VaccineFromDB vaccineFromDB = new VaccineFromDB();
        public VaccineWindow(int idAnimal)
        {
            InitializeComponent();
            this.idAnimal = idAnimal;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dgVaccine.Columns[0].Visibility = Visibility.Collapsed;
            LoadAnimal();
            LoadVaccine();
        }
        void LoadAnimal()
        {
            animal = animalFromDB.LoadAnimalById(idAnimal);
            tbName.Text = animal.Name;
            tbAge.Text = animal.Age;
            tbClub.Text = animal.NameClub;
            tbType.Text = animal.Type;
            tbBreed.Text = animal.Breed;
        }
        void LoadVaccine()
        {
            vaccines = vaccineFromDB.LoadVaccine(idAnimal);
            dgVaccine.DataContext = vaccines;
            dgVaccine.SetBinding(DataGrid.ItemsSourceProperty, new Binding() { Path = new PropertyPath(".") });
        }
    }
}
