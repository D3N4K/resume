﻿using AnimalShowApp.Classes;
using AnimalShowApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AnimalShowApp.Windows
{
    /// <summary>
    /// Логика взаимодействия для EditExpertWindow.xaml
    /// </summary>
    public partial class EditExpertWindow : Window
    {
        int idShow = 0;
        List<Ring> rings= new List<Ring>();
        RingFromDB ringFromDB = new RingFromDB();
        List<ExpertFull> experts = new List<ExpertFull>();
        ExpertFromDB expertFromDB = new ExpertFromDB();
        public EditExpertWindow(int idShow)
        {
            InitializeComponent();
            this.idShow = idShow;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadRing();
            LoadExpert();
        }
        void LoadRing()
        {
            rings = ringFromDB.LoadRing();
            cbRing.Items.Insert(0, "Выбрать");
            for(int i = 0; i < rings.Count; i++)
            {
                cbRing.Items.Insert(rings[i].Id, rings[i].Name);
            }
            cbRing.SelectedIndex = 0;
        }
        void LoadExpert()
        {
            experts = expertFromDB.LoadAllExpert();
            cbExpert.Items.Insert(0, "Выбрать");
            for (int i = 0; i < experts.Count; i++)
            {
                cbExpert.Items.Insert(experts[i].Id, experts[i].Name);
            }
            cbExpert.SelectedIndex = 0;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            expertFromDB.AddExpert(cbRing.SelectedIndex, cbExpert.SelectedIndex, idShow);
            DialogResult = true;
            this.Close();
        }
    }
}
