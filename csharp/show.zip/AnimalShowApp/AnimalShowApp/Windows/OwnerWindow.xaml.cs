﻿using AnimalShowApp.Classes;
using AnimalShowApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AnimalShowApp.Windows
{
    /// <summary>
    /// Логика взаимодействия для OwnerWindow.xaml
    /// </summary>
    public partial class OwnerWindow : Window
    {
        int idAnimal;
        Owner owner = new Owner();
        OwnerFromDB ownerFromDB = new OwnerFromDB();
        List<AnimalById> animalByOwners = new List<AnimalById>();
        AnimalFromDB animalFromDB = new AnimalFromDB();
        public OwnerWindow(int idAnimal)
        {
            InitializeComponent();
            this.idAnimal = idAnimal;
        }
        void LoadOwner()
        {
            owner = ownerFromDB.LoadOwner(idAnimal);
            tbFirstName.Text = owner.FirstName;
            tbLastName.Text = owner.LastName;
            tbPatronymic.Text = owner.Patronymic;
            tbSeriaNumber.Text = owner.SeriaPassport + " " + owner.NumberPassport;
            tbIssued.Text = owner.Issued;
            tbDateOfBirthday.Text = owner.DateOfBirthday;
        }
        void LoadAnimal()
        {
            animalByOwners = animalFromDB.LoadAnimalByOwner(idAnimal);
            dgAnimal.DataContext = animalByOwners;
            dgAnimal.SetBinding(DataGrid.ItemsSourceProperty, new Binding() { Path = new PropertyPath(".") });
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dgAnimal.Columns[0].Visibility = Visibility.Collapsed;
            LoadOwner();
            LoadAnimal();
        }
    }
}
