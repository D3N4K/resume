﻿using AnimalShowApp.Classes;
using AnimalShowApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AnimalShowApp.Windows
{
    /// <summary>
    /// Логика взаимодействия для EditShowWindow.xaml
    /// </summary>
    public partial class EditShowWindow : Window
    {
        int action;
        int idShow = 0;
        ShowFromDB showFromDB = new ShowFromDB();
        Show show = new Show();
        public EditShowWindow(int action, int idShow)
        {
            InitializeComponent();
            this.action = action;
            this.idShow = idShow;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if(action == 1)
            {
                tbTitle.Text = "Изменение данных выставки";
                btnAdd.Content = "Сохранить";
                ViewShowById();
            }
            else
            {
                tbTitle.Text = "Добавление новой выставки";
                btnAdd.Content = "Добавить";
            }
        }
        void ViewShowById()
        {
            show = showFromDB.LoadShowById(idShow);
            tbName.Text = show.NameShow;
            dpDate.Text = show.DateShow;
            tbTime.Text = show.TimeShow;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if(action == 0)
            {
                showFromDB.AddShow(tbName.Text, Convert.ToDateTime(dpDate.Text), tbTime.Text);
            }
            else
            {
                showFromDB.UpdateShow(idShow, tbName.Text, Convert.ToDateTime(dpDate.Text), tbTime.Text);
            }
            DialogResult = true;
            this.Close();
        }
    }
}
