﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalShowApp.Classes
{
    internal class Show
    {
        public int Id { get; set; }
        public string NameShow { get; set; }
        public string DateShow { get; set; }
        public string TimeShow { get; set; }

        public Show(int id, string nameShow, string dateShow, string timeShow)
        {
            Id = id;
            NameShow = nameShow;
            DateShow = dateShow;
            TimeShow = timeShow;
        }

        public Show()
        {
        }
    }
}
