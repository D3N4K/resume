﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalShowApp.Classes
{
    internal class User
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Patronymic { get; set; }
        public DateTime DateOfBirthday { get; set; }
        public string Login { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public string Email { get; set; }

        public User(int id, string firstName, string lastName, string patronymic, DateTime dateOfBirthday, string login, int roleId, string roleName, string email)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Patronymic = patronymic;
            DateOfBirthday = dateOfBirthday;
            Login = login;
            RoleId = roleId;
            RoleName = roleName;
            Email = email;
        }
        public User()
        {
        }
    }
}
