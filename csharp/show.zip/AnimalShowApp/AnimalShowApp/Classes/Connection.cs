﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalShowApp.Classes
{
    internal class Connection
    {
        internal static string connectionString = "Data Source=LAPTOP-U4M3FUAO\\MSSQLSERVER1;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;Initial Catalog=AnimalShowDB";
    }
}
