﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalShowApp.Classes
{
    internal class AnimalById
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Age { get; set; }
        public string NameClub { get; set; }
        public string Type { get; set; }
        public string Breed { get; set; }

        public AnimalById(int id, string name, string age, string nameClub, string type, string breed)
        {
            Id = id;
            Name = name;
            Age = age;
            NameClub = nameClub;
            Type = type;
            Breed = breed;
        }

        public AnimalById()
        {
        }
    }
}
