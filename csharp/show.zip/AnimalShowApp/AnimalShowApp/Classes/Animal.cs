﻿using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalShowApp.Classes
{
    internal class Animal
    {
        public int Number { get; set; }
        public int Id { get; set; }
        public string ImageAnimal { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string NameClub { get; set; }
        public string Type { get; set; }
        public string Breed { get; set; }
        public string Owner { get; set; }
        public int Place { get; set; }

        public Animal(int number, int id, string image, string name, int age, string nameClub, string type, string breed, string owner, int place)
        {
            Number = number;
            Id = id;
            if(image != "")
            {
                ImageAnimal = "../../Images/" + image;
            }
            else
            {
                ImageAnimal = "../../Images/picture.png";
            }
            Name = name;
            Age = age;
            NameClub = nameClub;
            Type = type;
            Breed = breed;
            Owner = owner;
            Place = place;
        }

        public Animal()
        {
        }
    }
}
