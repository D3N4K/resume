﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalShowApp.Classes
{
    internal class Owner
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Patronymic { get; set; }
        public string SeriaPassport { get; set; }
        public string NumberPassport { get; set; }
        public string Issued { get; set; }
        public string DateOfBirthday { get; set; }

        public Owner(int id, string firstName, string lastName, string patronymic, string seriaPassport, string numberPassport, string issued, string dateOfBirthday)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Patronymic = patronymic;
            SeriaPassport = seriaPassport;
            NumberPassport = numberPassport;
            Issued = issued;
            DateOfBirthday = dateOfBirthday;
        }

        public Owner()
        {
        }
    }
}
