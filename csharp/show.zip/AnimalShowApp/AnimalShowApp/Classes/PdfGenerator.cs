﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace AnimalShowApp.Classes
{
    internal class PdfGenerator
    {
        public void GenerateReport(string filePath, string showName, List<RingHasExpert> ringHasExperts, List<Animal> animals)
        {
            BaseFont baseFont = BaseFont.CreateFont("c:/Windows/Fonts/times.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            iTextSharp.text.Font font = new iTextSharp.text.Font(baseFont);
            Document document = new Document();
            PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(filePath, FileMode.Create));
            document.Open();
            Paragraph title = new Paragraph($"Результаты выставки {showName}:", font);
            title.Font.Size = 20;
            document.Add(title);
            title.Font.Size = 12;
            Paragraph expert = new Paragraph("\nЭксперты, обслуживающие ринги:", font);
            document.Add(expert);
            for(int i = 0; i < ringHasExperts.Count; i++)
            {
                Paragraph rings = new Paragraph($"{i+1}: {ringHasExperts[i].NameRing} - {ringHasExperts[i].FirstName} {ringHasExperts[i].LastName}({ringHasExperts[i].NameClub})", font);
                document.Add(rings);
            }
            Paragraph participants = new Paragraph("\nУчастники выставки:", font);
            document.Add(participants);
            for(int i = 0; i < animals.Count; i++)
            {
                Paragraph animal = new Paragraph($"{i+1}: {animals[i].Number} {animals[i].Name}({animals[i].NameClub}) {animals[i].Place} место", font);
                document.Add(animal);
            }
            Paragraph authograph = new Paragraph("\n\n\n\n\n(Дата, подпись, расшифровка)", font);
            authograph.Alignment = Element.ALIGN_RIGHT;
            document.Add(authograph);
            PdfContentByte cb = writer.DirectContent;
            cb.SetLineWidth(1f);
            cb.SetColorStroke(BaseColor.BLACK);
            cb.MoveTo(400, 110);
            cb.LineTo(565, 110);
            cb.Stroke();
            document.Close();
        }
        public void GenerateCertificate(string filePath, string showName, Animal animal)
        {
            BaseFont baseFont = BaseFont.CreateFont("c:/Windows/Fonts/times.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            iTextSharp.text.Font font = new iTextSharp.text.Font(baseFont);
            Image img = Image.GetInstance(@"..\..\Images\CertificateBack.png");
            Document document = new Document();
            PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(filePath, FileMode.Create));
            document.Open();
            PdfContentByte cb = writer.DirectContent;
            img.ScaleToFit(document.PageSize.Width, document.PageSize.Height);
            img.SetAbsolutePosition(0, 0);
            document.Add(img);
            cb.SetLineWidth(1f);
            cb.SetColorStroke(BaseColor.BLACK);
            cb.MoveTo(100, 400);
            cb.LineTo(500, 400);
            cb.Stroke();    
            Paragraph paragraph = new Paragraph("\n\n\n\n\nГрамота", font);
            paragraph.Font.Size = 35;
            paragraph.Alignment = Element.ALIGN_CENTER;
            document.Add(paragraph);
            paragraph.Font.Size = 14;
            paragraph = new Paragraph($"\n\n\nВручается участнику {animal.Name} под номером {animal.Number} за занятое {animal.Place} место", font);
            paragraph.Alignment = Element.ALIGN_CENTER;
            document.Add(paragraph);
            paragraph = new Paragraph($"в выставке {showName}", font);
            paragraph.Alignment = Element.ALIGN_CENTER;
            document.Add(paragraph);
            document.Close();
        }
    }
}
