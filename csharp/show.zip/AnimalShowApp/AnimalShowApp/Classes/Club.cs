﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalShowApp.Classes
{
    internal class Club
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Club(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public Club()
        {
        }
    }
}
