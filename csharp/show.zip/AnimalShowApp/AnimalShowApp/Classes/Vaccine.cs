﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalShowApp.Classes
{
    internal class Vaccine
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Date { get; set; }

        public Vaccine(int id, string name, string date)
        {
            Id = id;
            Name = name;
            Date = date;
        }

        public Vaccine()
        {
        }
    }
}
