﻿using AnimalShowApp.Windows;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace AnimalShowApp.Classes
{
    internal class Autorization
    {
        public User CheckAutorize(string login, string password)
        {
            User user = new User();
            SqlConnection connection = new SqlConnection(Connection.connectionString);
            try
            {
                if (!(login != "" && password != ""))
                {
                    MessageBox.Show("Заполните поля для входа!");
                    return user;
                }
                connection.Open();
                string query = "SelectUser";
                SqlCommand command = new SqlCommand(query, connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@login", login);
                SqlDataReader reader = command.ExecuteReader();
                if(reader.HasRows)
                {
                    reader.Read();
                    if (Verification.VerifySHA512Hash(password, reader["password"].ToString()))
                    {
                        AutorizationWindow.Fio = reader["first_name"].ToString() + reader["last_name"].ToString() + reader["patronymic"].ToString();
                        AutorizationWindow.UserId = Convert.ToInt32(reader["id_user"]);
                        AutorizationWindow.RoleId = Convert.ToInt32(reader["id_role"]);
                        user.Id = Convert.ToInt32(reader["id_user"]);
                        user.FirstName = reader["first_name"].ToString();
                        user.LastName = reader["last_name"].ToString();
                        user.Patronymic = reader["patronymic"].ToString();
                        user.DateOfBirthday = Convert.ToDateTime(reader["date_of_birthday"]);
                        user.Login = reader["login"].ToString();
                        user.RoleId = Convert.ToInt32(reader["id_role"]);
                        user.RoleName = reader["name_role"].ToString();
                        user.Email = reader["email"].ToString();
                        return user;
                    }
                    else
                    {
                        MessageBox.Show("Не правильный пароль!");
                        return user;
                    }
                }
                else
                {
                    MessageBox.Show("Не существует такого пользователя!");
                    return user;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return user;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
